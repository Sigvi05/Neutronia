<?php 
	$module = basename(__FILE__, ".php");
	require_once 'base.php';
?>