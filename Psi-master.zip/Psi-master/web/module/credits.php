<div class='section-header'>
	<span class='glyphicon glyphicon-heart'></span> 
	Psi Credits
</div>


No project is done with only one member, Psi is no exception, here's the cast of people to thank!<br><br>
<ul>
<li><b>All of my <a href="http://www.patreon.com/Vazkii">Patrons</a> and Donators</b> for being extremely kind as to support me every month with their own income.<br></li>
<li><b>Azanor</b> for letting me use his particles from Thaumcraft.<br></li>
<li><b>Enterbrain</b> for a bunch of resources (both sound and graphical) from the RPG Maker VX Ace and MV RTP.<br></li>
<li><b>Gelbooru</b> (nsfw) for the cute catgirls in the downloads page.<br></li>
<li><b>Le_Alchemist</b> for providing many hours of shameless fun.<br></li>
<li><b>MCPBot</b> for always being there for my obfuscation woes.<br></li>
<li><b>ScottWears</b> for hosting my website.<br></li>
<li><b>The TConstruct and OpenBlocks teams</b> for code snippets I took from their repositories.<br></li>
<li><b>Tsutomu Satou</b> for creating Mahouka Kokou no Rettousei, which Psi is loosely based on.<br></li>
<li><b>wiiv</b> for pretty much every art asset.<br></li>
<li><b>williewillus</b> for helping me figure out how the heck 1.8 works.<br></li>
</ul>