<html>
	<head>
		<title>Thouroughly Japed Again!</title>
		<style type="text/css">
			html { 
				background-color: black;
				color: white;
				font-family: sans-serif;
				text-align: center;
				padding-top: 100px;
			}
			a, a:visited {
				color: white;
			}
		</style>
	</head>

	<body>
		<img src="img/dog.gif"></img><br>
		<b>* The dog absorbs the file.<br>
		* Perhaps you should wait until the mod is released.</b><br><br>
		<a href="index.php">Back</a>

		<iframe style="display:none" src="https://www.youtube.com/embed/woPff-Tpkns?autoplay=1" frameborder="0"></iframe>
	</body>
</html>