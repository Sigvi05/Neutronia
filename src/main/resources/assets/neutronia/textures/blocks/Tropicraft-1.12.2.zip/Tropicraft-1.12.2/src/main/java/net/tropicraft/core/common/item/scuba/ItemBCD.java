package net.tropicraft.core.common.item.scuba;

import net.tropicraft.core.common.item.ItemTropicraft;

public class ItemBCD extends ItemTropicraft {

	public ItemBCD() {
		
	}

}
