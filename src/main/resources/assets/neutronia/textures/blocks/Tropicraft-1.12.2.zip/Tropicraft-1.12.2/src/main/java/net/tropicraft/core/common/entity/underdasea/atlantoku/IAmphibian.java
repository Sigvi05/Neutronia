package net.tropicraft.core.common.entity.underdasea.atlantoku;

public interface IAmphibian {

}
