package net.tropicraft.core.common.block;

import net.minecraft.block.BlockLadder;

// BlockLadder's constructor is protected, go figure.
public class BlockTropicraftLadder extends BlockLadder {

    public BlockTropicraftLadder() {
        
    }

}