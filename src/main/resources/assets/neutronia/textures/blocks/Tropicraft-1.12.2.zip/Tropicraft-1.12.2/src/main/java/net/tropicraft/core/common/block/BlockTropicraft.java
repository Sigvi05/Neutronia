package net.tropicraft.core.common.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockTropicraft extends Block {

	public BlockTropicraft(Material mat) {
		super(mat);
	}
	
}
