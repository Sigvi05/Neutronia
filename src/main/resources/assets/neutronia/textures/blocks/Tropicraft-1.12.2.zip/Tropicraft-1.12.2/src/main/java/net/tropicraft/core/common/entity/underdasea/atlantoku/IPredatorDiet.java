package net.tropicraft.core.common.entity.underdasea.atlantoku;

public interface IPredatorDiet {
	public Class[] getPreyClasses();
}
