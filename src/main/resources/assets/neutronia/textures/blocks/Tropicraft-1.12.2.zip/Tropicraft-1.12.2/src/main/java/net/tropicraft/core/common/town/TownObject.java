package net.tropicraft.core.common.town;

public class TownObject extends TownObjectBase {

	public TownObject() {
		
	}
	
}
