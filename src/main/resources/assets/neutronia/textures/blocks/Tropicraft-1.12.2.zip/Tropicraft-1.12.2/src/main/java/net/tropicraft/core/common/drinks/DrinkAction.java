package net.tropicraft.core.common.drinks;

import net.minecraft.entity.player.EntityPlayer;

public abstract class DrinkAction {
    public abstract void onDrink(EntityPlayer player);
}
