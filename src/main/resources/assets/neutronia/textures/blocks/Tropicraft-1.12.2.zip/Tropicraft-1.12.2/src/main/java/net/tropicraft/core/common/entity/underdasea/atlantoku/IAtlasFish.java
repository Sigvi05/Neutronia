package net.tropicraft.core.common.entity.underdasea.atlantoku;

public interface IAtlasFish {
	public int getAtlasSlot();
}
