package net.tropicraft.core.common.block;

import net.minecraft.block.material.Material;


public class BlockChunkOHead extends BlockTropicraft {

	public BlockChunkOHead() {
		super(Material.ROCK);
		this.setHardness(2.0F);
		this.setResistance(30F);
	}

}
