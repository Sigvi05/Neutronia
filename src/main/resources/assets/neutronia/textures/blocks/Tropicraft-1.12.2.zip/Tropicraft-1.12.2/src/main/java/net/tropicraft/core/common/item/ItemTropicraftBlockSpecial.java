package net.tropicraft.core.common.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlockSpecial;

public class ItemTropicraftBlockSpecial extends ItemBlockSpecial {

	public ItemTropicraftBlockSpecial(Block block) {
		super(block);
	}

}
