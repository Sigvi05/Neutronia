package net.tropicraft.core.proxy;

public class ServerProxy extends CommonProxy {

}
