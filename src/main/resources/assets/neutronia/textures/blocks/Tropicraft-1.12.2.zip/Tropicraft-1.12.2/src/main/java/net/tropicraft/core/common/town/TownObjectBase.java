package net.tropicraft.core.common.town;

public class TownObjectBase extends ManagedLocation {

	//public Resources resources;
	
	//maybe add npc members list
	
	public TownObjectBase() {
		super();
	}
	
}
