package net.tropicraft.core.common.item;


public class ItemTropicsOre extends ItemTropicraft {

	public ItemTropicsOre() {

	}

}
