package net.tropicraft.core.common.entity.passive;

import net.minecraft.world.World;

public class EntityKoaHunter extends EntityKoaBase {

    public EntityKoaHunter(World worldIn) {
        super(worldIn);
    }
}
