package net.tropicraft.core.common.item;

import net.minecraft.item.ItemFood;

public class ItemTropicraftFood extends ItemFood {

	public ItemTropicraftFood(int healAmount, float saturation) {
		super(healAmount, saturation, false);
	}
}
