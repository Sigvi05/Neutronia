# Astral Sorcery

Astral Sorcery is a magic mod for [Minecraft Forge](https://files.minecraftforge.net) 
focused around harnessing the powers of starlight and the constellations.  

## Links

#### Curse Forge: [Project Link](https://minecraft.curseforge.com/projects/astral-sorcery)
#### Discord: [Astral Sorcery on Discord](https://discord.gg/q37VRcT)


