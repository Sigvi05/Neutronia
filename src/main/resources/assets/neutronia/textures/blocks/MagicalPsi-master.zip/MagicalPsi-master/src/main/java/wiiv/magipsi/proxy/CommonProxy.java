package wiiv.magipsi.proxy;

public class CommonProxy {

	public void replacePsiAssets() {
		// NO-OP
	}
	
}
