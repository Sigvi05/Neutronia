# MCPConfig
Public facing repo for MCP SRG mappings. All rights reserved, instructions on use will be described later.
