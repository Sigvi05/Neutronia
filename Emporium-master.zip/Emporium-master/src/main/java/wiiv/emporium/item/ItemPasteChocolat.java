package wiiv.emporium.item;

public class ItemPasteChocolat extends ItemBaseFood {

	public ItemPasteChocolat() {
		super(2, 0.0F, false, "paste_chocolat");
		setMaxStackSize(16);
	}
}
