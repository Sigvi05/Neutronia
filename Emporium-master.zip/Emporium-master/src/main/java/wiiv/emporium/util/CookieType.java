package wiiv.emporium.util;

/**
 * @author p455w0rd
 *
 */
public enum CookieType {
	PLAIN, CHOCOLATE, STRAWBERRY
}
