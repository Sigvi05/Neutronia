package wiiv.emporium.api;

import wiiv.emporium.util.CookieType;

/**
 * @author p455w0rd
 *
 */
public interface ICookieJar {

	CookieType getContainedCookieType();
}
