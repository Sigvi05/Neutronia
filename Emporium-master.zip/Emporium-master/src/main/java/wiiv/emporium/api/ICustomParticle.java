package wiiv.emporium.api;

/**
 * @author p455w0rd
 *
 */
public interface ICustomParticle {
	boolean alive();
}
