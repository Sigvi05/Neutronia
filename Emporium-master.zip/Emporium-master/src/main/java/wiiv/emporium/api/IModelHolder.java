package wiiv.emporium.api;

/**
 * @author p455w0rd
 *
 */
public interface IModelHolder {
	void initModel();
}
